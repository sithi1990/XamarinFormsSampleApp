module.exports = {

    'secret': 'vappsecret',
    'database': 'mongodb://vuser:password@jello.modulusmongo.net:27017/bubA2gum'

};