﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VAppApiServiceAccess.Common;
using VAppApiServiceAccess.Models;

namespace VAppApiServiceAccess
{
    public class UserService
    {

        private const string GET_USERS_URL = "http://localhost:8079/api/users";
        private const string CREATE_USER_URL = "http://localhost:8079/api/createuser";
        public UserService()
        {
            
        }

        public List<User> ViewUsers()
        {
            HttpRequestHandler requestHandler = new HttpRequestHandler();
            requestHandler.AccessToken = AuthenticationService.AuthenticationToken;
            requestHandler.Method = "GET";
            requestHandler.Url = GET_USERS_URL;
            var users=requestHandler.SendRequest<List<User>>();
            return users;
        }

        public object CreateUser(User user)
        {
            HttpRequestHandler requestHandler = new HttpRequestHandler();
            requestHandler.Method = "POST";
            requestHandler.Url = CREATE_USER_URL;
            return requestHandler.SendRequest<User, object>(user);
        }
    }
}
