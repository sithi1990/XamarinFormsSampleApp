﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using VAppApiServiceAccess.Common;
using VAppApiServiceAccess.Models;

namespace VAppApiServiceAccess
{
    public class AuthenticationService
    {
        private const string AUTHENCATION_URL = "http://localhost:8079/api/authenticate";

        public static string authenticationToken;

        public static string AuthenticationToken
        {
            get { return authenticationToken; }
            set { authenticationToken= value; }
        }

        public static AuthenticationResult Authenticate(string userName, string password)
        {
            HttpRequestHandler requestHandler = new HttpRequestHandler();
            requestHandler.Url = AUTHENCATION_URL;
            requestHandler.Method = "POST";
            var user = new User() {UserName=userName,Password=password};
            var authenticationResult=requestHandler.SendRequest<User, AuthenticationResult>(user);
            authenticationToken = authenticationResult.Token;
            return authenticationResult;
        }

        
    }
}
