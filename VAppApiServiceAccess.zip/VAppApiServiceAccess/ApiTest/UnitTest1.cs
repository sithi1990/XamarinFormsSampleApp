﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VAppApiServiceAccess.Models;
using VAppApiServiceAccess;

namespace ApiTest
{
    [TestClass]
    public class AuthenticationServiceTest
    {
        string authenticationToken;

        [TestMethod]
        public void AddUserTest()
        {
            UserService userservice = new UserService();
            User user=new User(){FirstName="sithira1",LastName="pathirana1",Password="password1",UserName="sithi19901"};
            var isAdded=userservice.CreateUser(user);
            Assert.IsNotNull(isAdded);
        }
        
        [TestMethod]
        public void AuthenticateWith_ValidUserNameAndPassword()
        {
          var authenticationResponse = AuthenticationService.Authenticate("sithi19901", "password1");
          authenticationToken = authenticationResponse.Token;
          Assert.IsTrue(authenticationResponse.IsSuccess); 
           // Assert.IsNotNull();
        }

        [TestMethod]
        public void AuthenticateWith_InvalidUserNameAndPassword()
        {
            var authenticationResponse = AuthenticationService.Authenticate("user1x", "password");
            Assert.IsFalse(authenticationResponse.IsSuccess); 
           
        }

        [TestMethod]
        public void ViewUsersWithValidToken()
        {
            UserService userservice = new UserService();
            AuthenticationService.AuthenticationToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyIkX18iOnsic3RyaWN0TW9kZSI6dHJ1ZSwiZ2V0dGVycyI6e30sIndhc1BvcHVsYXRlZCI6ZmFsc2UsImFjdGl2ZVBhdGhzIjp7InBhdGhzIjp7Il9fdiI6ImluaXQiLCJwYXNzd29yZCI6ImluaXQiLCJuYW1lIjoiaW5pdCIsIl9pZCI6ImluaXQifSwic3RhdGVzIjp7Imlnbm9yZSI6e30sImRlZmF1bHQiOnt9LCJpbml0Ijp7Il9fdiI6dHJ1ZSwicGFzc3dvcmQiOnRydWUsIm5hbWUiOnRydWUsIl9pZCI6dHJ1ZX0sIm1vZGlmeSI6e30sInJlcXVpcmUiOnt9fSwic3RhdGVOYW1lcyI6WyJyZXF1aXJlIiwibW9kaWZ5IiwiaW5pdCIsImRlZmF1bHQiLCJpZ25vcmUiXX0sImVtaXR0ZXIiOnsiZG9tYWluIjpudWxsLCJfZXZlbnRzIjp7fSwiX2V2ZW50c0NvdW50IjowLCJfbWF4TGlzdGVuZXJzIjowfX0sImlzTmV3IjpmYWxzZSwiX2RvYyI6eyJfX3YiOjAsInBhc3N3b3JkIjoicGFzc3dvcmQxIiwibmFtZSI6InNpdGhpMTk5MDEiLCJfaWQiOiI1NzM4OTFhM2EzOTdmNDAwMGUwN2UxZDgifSwiX3ByZXMiOnsiJF9fb3JpZ2luYWxfc2F2ZSI6W251bGwsbnVsbF19LCJfcG9zdHMiOnsiJF9fb3JpZ2luYWxfc2F2ZSI6W119LCJpYXQiOjE0NjMzMjUxMjUsImV4cCI6MTQ2MzM2ODMyNX0.gZrUtCOPRcOSr-zKIjv1SPe0He4U1ptWAli0-hzdS-c";
            var users=userservice.ViewUsers();

        }
        //[TestMethod]
        //public void ViewUsersWith_InvalidAuthenticationToken()
        //{
        //    var userData=AuthenticationService.ViewUsers("InvlidToken");
        //    Assert.IsNull(userData.co);
        //    // Assert.IsNotNull();
        //}
    }
}
